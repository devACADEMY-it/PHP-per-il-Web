<!--

	PHP per il Web
	Inserire PHP in codice HTML

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<h1> <?php echo date("G:i:s"); ?> </h1>
</body>
</html>