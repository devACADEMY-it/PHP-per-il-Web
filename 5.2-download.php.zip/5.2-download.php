<!--

    PHP per il Web
    Download di file

    Disponibile su devACADEMY.it

-->

<?php
$file="documento.pdf";
header('Content-Type: application/octet-stream');
header('Content-Transfer-Encoding: Binary');
header("Content-disposition: attachment; filename=$file");
readfile($file);
?>
<a href="documento.pdf">Clicca qui per scaricare il documento</a>