<!--

    PHP per il Web
    Header HTTP e PHP

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<h1> Pagina di destinazione </h1>
</body>
</html>