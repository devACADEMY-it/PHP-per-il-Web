<!--

    PHP per il Web
    Elenco messaggi ricevuti dal form in homepage

    Disponibile su devACADEMY.it

-->

<?php

$url="localhost";
$username="root";
$password="";
$db="start_db";

?>