<!--

    PHP per il Web
    Header HTTP e PHP

    Disponibile su devACADEMY.it

-->

<?php
	/*$headers=getallheaders();
	var_dump($headers);*/

	//header('MiaHeader: 12345');

	//header('Refresh: 3');

	//header('Location: destinazione.php');

	header('Refresh: 5; destinazione.php');
?>

<h1>Stiamo per andare a destinazione...</h1>