﻿<!--

    PHP per il Web
    Esempio riepilogo: login con gestione utenti

    Disponibile su devACADEMY.it

-->

<?php
require_once('config_db.php');
if (isset($_POST['invio']) && !empty($_POST['username'])
		&& !empty($_POST['password']) && !empty($_POST['ripeti_password']))
{
	if ($_POST['password']== $_POST['ripeti_password'])
	{
		$stmt=$dbh->prepare("INSERT INTO utente (username, password)
					 VALUES (:username, PASSWORD(:password))");
		$stmt->bindParam(':username', $_POST['username']);
		$stmt->bindParam(':password', $_POST['password']);
		$stmt->execute();
		header('Location: form.php');
	}
	else
	{
		$errore="Le password fornite non coincidono";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST">
<p><strong>Scegli username e password</strong></p>
 <?php
   if (!empty($errore))
    echo "<p class=\"errore\">$errore</p>";
 ?>
 <p>
  <input type="text" name="username" size="50" placeholder="Scegli il tuo username"><br>
  </p>
  <p>
  <input type="password" name="password" size="50" placeholder="Scegli una password"><br>
  </p>
  <p>
  <input type="password" name="ripeti_password" size="50" placeholder="Ripeti la password"><br>
  </p>
  <p>
  <input type="submit" name="invio" value="Invio" size="20">
  </p>
</form>
</div>
</body>
</html>