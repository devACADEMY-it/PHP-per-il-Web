<!--

    PHP per il Web
    Salvare nel database dati inviati via form

    Disponibile su devACADEMY.it

-->

<?php

 require_once('config_db.php');
 require_once('dbmanager.php');

 $dbmanager=new DbManager($url, $username, $password, $db);
 $dbmanager->salvaContatto($_POST['name'], $_POST['email'], $_POST['phone'], $_POST['message']);

?>