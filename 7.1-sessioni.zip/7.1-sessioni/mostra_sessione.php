<!--

    PHP per il Web
    Gestione dei dati nelle sessioni

    Disponibile su devACADEMY.it

-->

<?php
  session_start();
?>
<!DOCTYPE HTML>

<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php var_dump($_SESSION); ?>
</body>
</html>