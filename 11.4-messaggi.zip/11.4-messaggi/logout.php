<!--

    PHP per il Web
    Elenco messaggi ricevuti dal form in homepage

    Disponibile su devACADEMY.it

-->

<?php

 session_start();
 session_destroy();
 header('Location: login.php');

?>