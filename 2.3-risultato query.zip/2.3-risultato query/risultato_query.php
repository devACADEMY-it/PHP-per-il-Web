<!--

	PHP per il Web
	Mostrare risultati di una query in una pagina web

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<ul>
<?php
	$url="localhost";
	$username="root";
	$password="";
	$db="esempio_db";

	try
	{
		$db=new PDO("mysql:host=$url;dbname=$db", $username, $password);
		$stmt=$db->query("SELECT * FROM persone");
		foreach($stmt as $row)
		{?>
		 <li><?php echo $row['nome']." ".$row['cognome']?></li>
		<?php }
	}
	catch(PDOException $e)
	{
		print $e->getMessage();
		die();
	}
?>
</ul>
</div>
</body>
</html>