<!--

    PHP per il Web
    Form con modifica dati

    Disponibile su devACADEMY.it

-->

<?php
	require_once('config_db.php');
	print_r($_POST);
	echo "<br><br>";

	$ok=TRUE;
	if (array_key_exists('eta', $_POST) && filter_var($_POST['eta'], FILTER_VALIDATE_INT))
		echo "eta OK <br>";
	else
	{
		$ok=FALSE;
		echo "eta KO <br>";
	}

	if (array_key_exists('nome', $_POST) && filter_var($_POST['nome'],
			FILTER_VALIDATE_REGEXP,
			array(
				"options"=> array("regexp"=>"/^([a-zA-Z'\ ])+$/")
			)))
		echo "nome OK <br>";
	else
	{
		$ok=FALSE;
		echo "nome KO <br>";
	}

	if (array_key_exists('cognome', $_POST) && filter_var($_POST['cognome'],
			FILTER_VALIDATE_REGEXP,
			array(
				"options"=> array("regexp"=>"/^([a-zA-Z'\ ])+$/")
			)))
		echo "cognome OK <br>";
	else
	{
		$ok=FALSE;
		echo "cognome KO <br>";
	}

	if (!$ok)
		die("Impossibile procedere con inserimento");

	$id=$_POST['id'];
	try
	{
		if ($id>0)
			$stmt=$dbh->prepare("UPDATE persone
				SET nome=:nome, cognome=:cognome, eta=:eta WHERE id=$id");
		else
			$stmt=$dbh->prepare("INSERT INTO persone (nome, cognome, eta)
			   VALUES (:nome,:cognome,:eta)");
		$stmt->bindParam(':nome', $_POST['nome']);
		$stmt->bindParam(':cognome', $_POST['cognome']);
		$stmt->bindParam(':eta', $_POST['eta']);
		$stmt->execute();
		echo "Inserimento/modifica OK";
	}
	catch(PDOException $e)
	{
		echo "<br>Errore di inserimento/modifica<br>";
		echo "Descrizione: <b>".$e->getMessage()."</b>";
	}

?>