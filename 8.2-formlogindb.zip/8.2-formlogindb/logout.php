<!--

    PHP per il Web
    Login e database

    Disponibile su devACADEMY.it

-->

<?php
	session_start();
	session_destroy();
	header("Location: form.php");
?>