﻿<!--

    PHP per il Web
    Esempio riepilogo: login con gestione utenti

    Disponibile su devACADEMY.it

-->

<?php
require_once('config_db.php');


   if (isset($_POST['username']) && !empty($_POST['username']) && !empty($_POST['password'])) {
	   $stmt=$dbh->prepare("SELECT count(*) as trovati FROM `utente` WHERE username=:username AND password=PASSWORD(:password)");
	   $stmt->bindParam(':username', $_POST['username']);
	   $stmt->bindParam(':password', $_POST['password']);
	   $stmt->execute();
	   $quanti=$stmt->fetch()['trovati'];
	   if ($quanti>0) {
		          session_start();
                  $_SESSION['ora_login'] = date("G:i:s");
                  $_SESSION['username'] = 'admin';

				  header('Location: protetti.php');}
               else {
                  $errore="Credenziali non corrette!!";
               }
   }
?>
<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST">
<p><strong>Login</strong></p>
<?php
if (!empty($errore))
 echo "<p class=\"errore\">$errore</p>";
?>
 <p>
  <input type="text" name="username" size="50" placeholder="username"><br>
  </p>
  <p>
  <input type="password" name="password" size="50" placeholder="password"><br>
  </p>
  <p>
  <input type="submit" value="Invio" size="20">
  </p>
  <br><br>
  <p>Non sei ancora registrato? <a href="registrazione.php">Registrati!</a></p>
</form>
</div>
</body>
</html>