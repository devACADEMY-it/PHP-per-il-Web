<!--

	PHP per il Web
	Costrutti condizionali PHP e HTML

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php
	$numero=72;
	if ($numero%2==0)
	{
?>
	<h1>Numero pari</h1>
<?php
	} else {
?>
	<h1>Numero dispari</h1>
<?php } ?>
</body>
</html>