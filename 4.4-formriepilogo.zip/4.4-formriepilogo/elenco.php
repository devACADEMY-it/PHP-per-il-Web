<!--

    PHP per il Web
    Esempio riepilogo: form, database e risultato query

    Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<?php
   require_once('config_db.php');
   ?>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="lista">
<div id="menu">
<a class="nuovo" href="form.php"><img src="new.png" width="25" height="25"/></a>
</div>
<ul>
<?php

	try
	{
		$stmt=$dbh
		->query("SELECT * FROM persone");

		foreach($stmt as $row)
		{?>
		 <li>
		 <a href="form.php?id=<?php echo $row['id']?>">
			<?php echo $row['nome']." ".$row['cognome'].", anni "
			            .$row['eta']." (id=".$row['id'].")"?>
		</a>
		 </li>
		<?php }
	}
	catch(PDOException $e)
	{
		print $e->getMessage();
		die();
	}
?>
</ul>
</div>

</body>
</html>