<!--

	PHP per il Web
	Query e pagine web

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php
	$url="localhost";
	$username="root";
	$password="";
	$db="esempio_db";

	try
	{
		$db=new PDO("mysql:host=$url;dbname=$db", $username, $password);
		$stmt=$db->query("SELECT count(*) as quanti FROM persone");
		$row=$stmt->fetch();
		echo $row['quanti'];
	}
	catch(PDOException $e)
	{
		print $e->getMessage();
		die();
	}
?>
</body>
</html>