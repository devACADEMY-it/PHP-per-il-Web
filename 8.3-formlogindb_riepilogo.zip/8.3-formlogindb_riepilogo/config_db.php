<!--

    PHP per il Web
    Esempio riepilogo: login con gestione utenti

    Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="esempio_db";


try {
    $dbh = new PDO("mysql:host=$url;dbname=$db", $username, $password );
    $dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
} catch (PDOException $e) {
    print $e->getMessage() . "<br/>";
    die();
}
?>