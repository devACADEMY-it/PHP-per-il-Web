<!--

    PHP per il Web
    Login: preparazione

    Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="start_db";

?>