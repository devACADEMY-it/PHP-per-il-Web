<!--

	PHP per il Web
	Integrazione database in PHP: organizzazione del codice

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php
	$url="localhost";
	$username="root";
	$password="";
	$db="esempio_db";

	try
	{
		$db=new PDO("mysql:host=$url;dbname=$db", $username, $password);
		echo "Connessione riuscita";
	}
	catch(PDOException $e)
	{
		print $e->getMessage();
		die();
	}
?>
</body>
</html>