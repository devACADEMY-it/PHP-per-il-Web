<!--

    PHP per il Web
    Gestione dei dati nelle sessioni

    Disponibile su devACADEMY.it

-->

<?php
session_start();
$_SESSION['valore']='Testo da conservare';
$_SESSION['ora']=date("G:i:s");
?>
<!DOCTYPE HTML>

<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php var_dump($_SESSION); ?>
</body>
</html>