<!--

	PHP per il Web
	PHP e fogli di stile CSS

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile.css"/>
</head>
<body>
<div id="centrale">
<?php
for($i=0;$i<10;$i++)
{?>
<p class="<?php echo ($i%2==0)?'pari':'dispari' ?>" >
	<?php echo $i?>
</p>
<?php } ?>
</div>
</body>
</html>