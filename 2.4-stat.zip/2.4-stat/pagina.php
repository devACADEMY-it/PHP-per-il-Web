<!--

	PHP per il Web
	Esercizio riepilogo: salvare e visualizzare statistiche

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<?php
	require_once('config_db.php');
	$pagina=basename($_SERVER['PHP_SELF']);
	$stmt=$dbh->prepare("
		INSERT INTO statistiche(pagina, visite)
		VALUES (:pagina, 1)
		ON DUPLICATE KEY UPDATE
		visite=visite+1
	");
	$stmt->bindParam(':pagina', $pagina);
	$stmt->execute();
?>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>

<h1>Benvenuti!!</h1>
</body>
</html>