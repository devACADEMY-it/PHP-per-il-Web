<!--

    PHP per il Web
    Inserire un nuovo elemento nel portfolio

    Disponibile su devACADEMY.it

-->

<?php
	session_start();
	if (!isset($_SESSION['username']))
		header('Location: login.php');
	require_once('config_db.php');
	require_once('dbmanager.php');
	$dbmanager=new DbManager($url, $username, $password, $db);

	if (isset($_POST['titolo']) && isset($_POST['testo']) && isset($_FILES['immagine']))
	{
		$file=$_FILES['immagine'];
		$nome_immagine=explode('-', $file['name'])[0];

		$dbmanager->nuovo($nome_immagine, $_POST['titolo'], $_POST['testo']);

		if ($file['error']==UPLOAD_ERR_OK && is_uploaded_file($file['tmp_name']))
		{
			$res=move_uploaded_file($file['tmp_name'], '../start/img/portfolio/'.$file['name']);
		}

		header("Location: gestione_portfolio.php");
	}
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">
    <meta name="author" content="">
    <title>SB Admin - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body class="bg-dark">

    <div class="container">

      <div class="card card-register mx-auto mt-5">
        <div class="card-header">
          Aggiungi un progetto nel portfolio
        </div>
        <div class="card-body">
          <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
              <label for="titolo">Titolo</label>
              <input type="text" class="form-control" id="titolo" name="titolo" placeholder="Titolo">
            </div>
            <div class="form-group">
              <label for="testo">Testo</label>
              <input type="text" class="form-control" id="testo" name="testo" placeholder="Testo">
            </div>
			<div class="form-group">
              <label for="immagine">Scegli un'immagine</label>
              <input type="file" class="form-control" id="immagine" name="immagine" placeholder="Immagine">
            </div>

            <button type="submit" class="btn btn-primary">Salva</button>
          </form>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>