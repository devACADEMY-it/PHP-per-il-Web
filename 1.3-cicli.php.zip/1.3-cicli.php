<!--

	PHP per il Web
	Cicli PHP e HTML

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
	<?php
		for ($i=0; $i<10; $i++)
		{
	?>
		<p>Iterazione n. <?php echo $i; ?></p>
	<?php
		}
	?>
</body>
</html>