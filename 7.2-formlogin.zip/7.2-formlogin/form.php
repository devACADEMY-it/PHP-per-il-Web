﻿<!--

    PHP per il Web
    Esempio riepilogo: login (senza database)

    Disponibile su devACADEMY.it

-->

<?php
if (isset($_POST['username']) && !empty($_POST['username']) && !empty($_POST['password']))
{
	if ($_POST['username']=='admin' && $_POST['password']=='default')
	{
		session_start();
		$_SESSION['username']='admin';
		$_SESSION['ora']=date('G:i:s');
		header('Location: protetti.php');
	}
	else
	{
		$errore="Credenziali non corrette!";
	}
}
?>
<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST">
<p><strong>Login</strong></p>
<?php
if (!empty($errore))
	echo "<p class=\"errore\">$errore</p>";
?>
 <p>
  <input type="text" name="username" size="50" placeholder="username"><br>
  </p>
  <p>
  <input type="password" name="password" size="50" placeholder="password"><br>
  </p>
  <p>
  <input type="submit" value="Invio" size="20">
  </p>
</form>
</div>
</body>
</html>