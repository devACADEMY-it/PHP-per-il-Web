<!--

    PHP per il Web
    Esposizione random di contenuti

    Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="start_db";

?>