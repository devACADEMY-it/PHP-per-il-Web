<!--

    PHP per il Web
    Modificare un elemento del portfolio (parte 2)

    Disponibile su devACADEMY.it

-->

<?php
class DbManager
{
	private $dbh;

	function __construct($url,$username, $password, $db)
	{
		try {
			$this->dbh = new PDO("mysql:host=$url;dbname=$db", $username, $password );
			$this->dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch (PDOException $e) {

		}
	}

	function leggiPortfolio($id)
	{
		$res=$this->dbh->query("SELECT * FROM portfolio WHERE id=$id");
		$res->setFetchMode(PDO::FETCH_ASSOC);
		return $res->fetch();
	}

	function modifica($id, $immagine, $titolo, $testo)
	{
		$imm_set=(strlen($immagine)>0)?" immagine=:immagine,":'';
		$stmt=$this->dbh->prepare("UPDATE portfolio
				SET $imm_set titolo=:titolo, testo=:testo
				WHERE id=:id");
		$stmt->bindParam(":id", $id);
		if (strlen($immagine)>0)
			$stmt->bindParam(":immagine", $immagine);
		$stmt->bindParam(":titolo", $titolo);
		$stmt->bindParam(":testo", $testo);
		$stmt->execute();
	}

	function nuovo($immagine, $titolo, $testo)
	{
		$stmt=$this->dbh->prepare("INSERT INTO portfolio
				(immagine, titolo, testo)
				VALUES
				(:immagine, :titolo, :testo)");
		$stmt->bindParam(":immagine", $immagine);
		$stmt->bindParam(":titolo", $titolo);
		$stmt->bindParam(":testo", $testo);
		$stmt->execute();
	}

	function cancella($id)
	{
		$stmt=$this->dbh->prepare("DELETE FROM portfolio WHERE id=:id");
		$stmt->bindParam(":id", $id);
		$stmt->execute();
	}

	function listaPortfolio()
	{
		$res=$this->dbh->query("SELECT * FROM portfolio");
		$res->setFetchMode(PDO::FETCH_ASSOC);
		return $res->fetchAll();
	}

	function numeroMessaggi()
	{
		$res=$this->dbh->query("SELECT count(*) as numero_messaggi FROM messaggio");
		$valore=$res->fetch()['numero_messaggi'];
		return $valore;
	}

	function listaMessaggi()
	{
		$res=$this->dbh->query("SELECT * FROM messaggio");
		$res->setFetchMode(PDO::FETCH_ASSOC);
		return $res->fetchAll();
	}

	function verificaCredenziali($username, $password)
	{
		$stmt=$this->dbh->prepare("SELECT count(*) as quanti FROM utente
			WHERE username=:username AND password=PASSWORD(:password)");
		$stmt->bindParam(':username', $username);
		$stmt->bindParam(':password', $password);
		$stmt->execute();
		$quanti=$stmt->fetch()['quanti'];
		return $quanti>0;
	}

	function leggiConfigurazione($nome)
	{
		$stmt=$this->dbh->prepare("SELECT valore FROM configurazione WHERE nome=:nome");
		$stmt->bindParam(':nome', $nome);
		$stmt->execute();
		$valore=$stmt->fetch()['valore'];
		return $valore;
	}

	function portfolioRandom()
	{
		$res=$this->dbh->query("SELECT * FROM portfolio ORDER BY RAND() LIMIT 3");
		$res->setFetchMode(PDO::FETCH_ASSOC);
		return $res->fetchAll();
	}

	function salvaContatto($nome, $email, $telefono, $testo)
	{
		$stmt=$this->dbh->prepare("INSERT INTO messaggio
			(nome, email, telefono, testo)
			VALUES
			(:nome, :email, :telefono, :testo)");
		$stmt->bindParam(":nome", $nome);
		$stmt->bindParam(":email", $email);
		$stmt->bindParam(":telefono", $telefono);
		$stmt->bindParam(":testo", $testo);
		$stmt->execute();

	}


}
?>