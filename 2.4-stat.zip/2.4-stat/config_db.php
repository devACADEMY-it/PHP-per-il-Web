<!--

	PHP per il Web
	Esercizio riepilogo: salvare e visualizzare statistiche

	Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="statistiche";


try {
    $dbh = new PDO("mysql:host=$url;dbname=$db", $username, $password );

} catch (PDOException $e) {
    print $e->getMessage() . "<br/>";
    die();
}
?>