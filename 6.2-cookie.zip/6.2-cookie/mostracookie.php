<!--

    PHP per il Web
    Esempio di utilizzo dei Cookie

    Disponibile su devACADEMY.it

-->

<?php
	var_dump($_COOKIE);
?>