<!--

    PHP per il Web
    Gestione dei dati nelle sessioni

    Disponibile su devACADEMY.it

-->

<?php
 session_start();
 if (session_destroy())
	echo "Sessione distrutta";
 else
	echo "Sessione non distrutta";
?>
<!DOCTYPE HTML>

<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>

</body>
</html>