<!--

    PHP per il Web
    Esempio di utilizzo dei Cookie

    Disponibile su devACADEMY.it

-->

<?php
	setcookie("my_id","pippo");
	setcookie("ora", date('G:i:s'), time()+3600);

?>