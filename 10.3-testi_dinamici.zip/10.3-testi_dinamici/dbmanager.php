<!--

    PHP per il Web
    Testo dinamico recuperato da database

    Disponibile su devACADEMY.it

-->

<?php
class DbManager
{
	private $dbh;

	function __construct($url,$username, $password, $db)
	{
		try {
			$this->dbh = new PDO("mysql:host=$url;dbname=$db", $username, $password );
			$this->dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch (PDOException $e) {

		}
	}

	function leggiConfigurazione($nome)
	{
		$stmt=$this->dbh->prepare("SELECT valore FROM configurazione WHERE nome=:nome");
		$stmt->bindParam(':nome', $nome);
		$stmt->execute();
		$valore=$stmt->fetch()['valore'];
		return $valore;
	}
}
?>