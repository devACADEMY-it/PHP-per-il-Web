<!--

    PHP per il Web
    Form post e database (salvare dati inviati da form)

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST" action="ricezione.php">
<p><strong>Inserimento dati</strong></p>
 <p>
  <input type="text" name="nome" size="50" placeholder="Inserisci il nome"><br>
  </p>
  <p>
  <input type="text" name="cognome" size="50" placeholder="Inserisci il cognome"><br>
  </p>
  <p>
  <input class="corto" type="text" name="eta" placeholder="Inserisci l'età"><br>
  </p>
  <p>
  <input type="submit" value="Invio" size="20">
  </p>
</form>
</div>
</body>
</html>