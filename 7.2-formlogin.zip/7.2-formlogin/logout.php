<!--

    PHP per il Web
    Esempio riepilogo: login (senza database)

    Disponibile su devACADEMY.it

-->

<?php
	session_start();
	session_destroy();
	header("Location: form.php");
?>