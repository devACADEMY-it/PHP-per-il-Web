<!--

	PHP per il Web
	Uso di array $_GET

	Disponibile su devACADEMY.it

-->

<?php
	echo "Ricevuti ".count($_GET)." parametri via GET<br>";
	print_r($_GET);
?>