<!--

    PHP per il Web
    Testo dinamico recuperato da database

    Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="start_db";

?>