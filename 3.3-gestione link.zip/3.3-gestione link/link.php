<!--

    PHP per il Web
    Gestione dei link

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<?php
for($i=2;$i<=10;$i++)
{?>
<p> <a href="tabellina.php?numero=<?php echo $i?>"> Tabellina del <?php echo $i?></a>
</p>
<?php } ?>
</body>
</html>