<!--

    PHP per il Web
    Form e metodo POST

    Disponibile su devACADEMY.it

-->

<?php
	print_r($_POST);

	echo "Nome: ".$_POST['nome']."<br>";
	echo "Cognome: ".$_POST['cognome']."<br>";
	echo "Eta: ".$_POST['eta']."<br>";
?>