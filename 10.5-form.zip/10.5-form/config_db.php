<!--

    PHP per il Web
    Salvare nel database dati inviati via form

    Disponibile su devACADEMY.it

-->

<?php

$url="localhost";
$username="root";
$password="";
$db="start_db";

?>