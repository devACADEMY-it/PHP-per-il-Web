<!--

    PHP per il Web
    Esempio riepilogo: login con gestione utenti

    Disponibile su devACADEMY.it

-->

<?php
session_start();
session_destroy();
header("Location: form.php");
?>