<!--

    PHP per il Web
    Upload di file

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST" action="testupload.php" enctype="multipart/form-data">
  Descrizione del file<br>
  <textarea name="descrizione" rows="4" cols="50">

  </textarea>
  <input type="file" name="da_caricare" />
  <br><br>
  <input type="submit" value="Carica file" />
</form>
</div>
</body>
</html>