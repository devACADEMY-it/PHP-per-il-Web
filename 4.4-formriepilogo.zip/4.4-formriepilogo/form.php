﻿<!--

    PHP per il Web
    Esempio riepilogo: form, database e risultato query

    Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<?php
	require_once('config_db.php');
	if (array_key_exists('id', $_GET))
	{
		$id=$_GET['id'];
		$stmt = $dbh->query("SELECT * FROM persone WHERE id=$id");
		$res=$stmt->fetch(PDO::PARAM_STR);
		$nome=$res['nome'];
		$cognome=$res['cognome'];
		$eta=$res['eta'];
	}
	else
		{
			$nome='';
			$cognome='';
			$eta='';
			$id=0;
		}
?>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST" action="ricezione.php">
 <p>
  Nome:<br>
  <input type="text" name="nome" size="50" value="<?php echo $nome?>"><br>
  </p>
  <p>
  Cognome:<br>
  <input type="text" name="cognome" size="50" value="<?php echo $cognome?>"><br>
  </p>
  <p>
  Età:<br>
  <input type="text" name="eta" class="corto" value="<?php echo $eta?>"><br>
  </p>
  <input type="hidden" name="id" value="<?php echo $id?>">
  <p>
  <input type="submit" value="Invio" size="20">
  </p>
</form>
</div>
</body>
</html>