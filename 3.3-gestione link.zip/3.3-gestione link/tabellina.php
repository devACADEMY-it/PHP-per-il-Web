<!--

    PHP per il Web
    Gestione dei link

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_tab.css"/>
</head>
<body>
<?php $numero=$_GET['numero']; ?>
<div id="centrale">
<h1>Tabellina del <?php echo $numero?> </h1>
<?php

for($i=1;$i<=10;$i++)
{?>
<p class="<?php echo ($i%2==0)?'pari':'dispari'?>">
	<?php
			$risultato=$i*$numero;
			echo "$numero * $i = $risultato";?>
</p>
<?php } ?>
</div>
</body>
</html>