<!--

    PHP per il Web
    Esercizio riepilogo: paginazione dei risultati di una query

    Disponibile su devACADEMY.it

-->

<!DOCTYPE html>
<?php
   require_once('config_db.php');
   $limit=5;
   if (array_key_exists('pag', $_GET) && $_GET['pag']>0)
   {
	   $pagina_corrente=$_GET['pag'];
	   $limit_text=(($pagina_corrente-1)*$limit).",".$limit;
   }
   else
   {
	   $limit_text=$limit;
   }
   $totale=$dbh->query(
	'SELECT count(*) as totale
	FROM persone'
   )->fetch()['totale'];

   $num_pagine=ceil($totale/$limit);
   ?>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<p>
<?php for($i=1;$i<=$num_pagine;$i++)
		echo "
			<a href=\"?pag=$i\">$i</a>
		";

?>
</p>
<ul>
<?php

	try
	{

		$stmt=$dbh
		->query("SELECT * FROM persone LIMIT $limit_text");

		foreach($stmt as $row)
		{?>
		 <li><?php echo $row['nome']." ".$row['cognome']." (id=".$row['id'].")"?></li>
		<?php }
	}
	catch(PDOException $e)
	{
		print $e->getMessage();
		die();
	}
?>
</ul>
</div>

</body>
</html>