<!--

    PHP per il Web
    Upload di file

    Disponibile su devACADEMY.it

-->

<?php
var_dump($_POST);
var_dump($_FILES);

if (isset($_FILES['da_caricare']))
{
	$file=$_FILES['da_caricare'];
	if ($file['error']==UPLOAD_ERR_OK && is_uploaded_file($file['tmp_name']))
	{
		$res=move_uploaded_file($file['tmp_name'], $file['name']);
		echo $res?'Caricamento eseguito':'Caricamento fallito';
	}
}
?>