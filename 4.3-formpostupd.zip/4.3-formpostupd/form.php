<!--

    PHP per il Web
    Form con modifica dati

    Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<?php
require_once('config_db.php');
if (array_key_exists('id', $_GET))
{
	$id=$_GET['id'];
	$stmt=$dbh->query("SELECT * FROM persone WHERE id=$id");
	$res=$stmt->fetch(PDO::PARAM_STR);
	$nome=$res['nome'];
	$cognome=$res['cognome'];
	$eta=$res['eta'];
}
else
{
	$nome='';
	$cognome='';
	$eta='';
	$id=0;
}
?>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_db.css"/>
</head>
<body>
<div id="centrale">
<form method="POST" action="ricezione.php">
<p><strong>Inserimento dati</strong></p>
 <p>
  <input type="text" name="nome" size="50" value="<?php echo $nome?>" placeholder="Inserisci il nome"><br>
  </p>
  <p>
  <input type="text" name="cognome" size="50"  value="<?php echo $cognome?>" placeholder="Inserisci il cognome"><br>
  </p>
  <p>
  <input class="corto" type="text" name="eta" value="<?php echo $eta?>" placeholder="Inserisci l'età"><br>
  </p>
  <input type="hidden" name="id" value="<?php echo $id?>">
  <p>
  <input type="submit" value="Invio" size="20">
  </p>
</form>
</div>
</body>
</html>