<!--

    PHP per il Web
    Login: completamento

    Disponibile su devACADEMY.it

-->

<?php
$url="localhost";
$username="root";
$password="";
$db="start_db";

?>