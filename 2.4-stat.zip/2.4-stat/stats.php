<!--

	PHP per il Web
	Esercizio riepilogo: salvare e visualizzare statistiche

	Disponibile su devACADEMY.it

-->

<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
   <link rel="stylesheet" type="text/css" href="stile_stat.css"/>
</head>
<body>
<div id="centrale">
<table>
<?php
	require_once('config_db.php');
	$stmt=$dbh->query("SELECT * FROM statistiche");
	foreach($stmt as $row)
	{?>
	<tr>
		<td class="sx"><?php echo $row['pagina'];?></td>
		<td class="dx"><?php echo $row['visite'];?></td>
	</tr>
	<?php } ?>
</table>
</div>
</body>
</html>