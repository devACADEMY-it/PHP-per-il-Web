<!--

    PHP per il Web
    Login: completamento

    Disponibile su devACADEMY.it

-->

<?php

 session_start();
 session_destroy();
 header('Location: login.php');

?>