<!--

    PHP per il Web
    Esempio riepilogo: login (senza database)

    Disponibile su devACADEMY.it

-->

<?php
session_start();
if (!isset($_SESSION['username']))
{
	header("Location: form.php");
}
?>
<!DOCTYPE HTML>
<html>
<head>
   <title>Esempi PHP</title>
</head>
<body>
<h1> Contenuti riservati!! </h1>
<p><a href="logout.php">Logout</a></p>
</body>
</html>