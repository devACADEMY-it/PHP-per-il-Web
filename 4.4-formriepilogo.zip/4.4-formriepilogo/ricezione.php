<!--

    PHP per il Web
    Esempio riepilogo: form, database e risultato query

    Disponibile su devACADEMY.it

-->

<?php
	require_once('config_db.php');

	$ok=TRUE;
	if (array_key_exists('eta', $_POST) && filter_var($_POST['eta'], FILTER_VALIDATE_INT))
		echo "eta OK<BR>";
	else
		{
			$ok=FALSE;
			echo "eta KO<BR>";
		}
	if (array_key_exists('nome', $_POST) && filter_var($_POST['nome'], FILTER_VALIDATE_REGEXP,
		array(
             "options" => array("regexp"=>"/^([a-zA-Z'\ ])+$/"))))
		echo "nome OK<BR>";
	else
		{
			$ok=FALSE;
    	    echo "nome KO<BR>";
		}

	if (array_key_exists('cognome', $_POST) && filter_var($_POST['cognome'], FILTER_VALIDATE_REGEXP,
		array(
             "options" => array("regexp"=>"/^([a-zA-Z'\ ])+$/"))))
		echo "cognome OK<BR>";
	else
		{
			$ok=FALSE;
			echo "cognome KO<BR>";
		}


	if (!$ok)
		die("Impossibile procedere con inserimento");

	$id=$_POST['id'];

	try {
	//$stmt = $dbh->prepare("INSERT INTO persone (nome, cognome, eta) VALUES (:nome, :cognome, :eta)");
	if ($id>0)
		$stmt = $dbh->prepare("UPDATE persone SET nome=:nome, cognome=:cognome, eta=:eta WHERE id=$id");
	else
		$stmt = $dbh->prepare("INSERT INTO persone (nome, cognome, eta) VALUES (:nome, :cognome, :eta)");

	$stmt->bindParam(':nome', $_POST['nome']);
	$stmt->bindParam(':cognome', $_POST['cognome']);
	$stmt->bindParam(':eta', $_POST['eta']);
	$stmt->execute();
	echo "Inserimento OK";
	}
	catch (PDOException $e) {
		echo "<br>Errore di inserimento<br>";
		echo "Descrizione: <b>".$e->getMessage()."</b>";

    	}

?>